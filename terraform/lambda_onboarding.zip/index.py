import json
import boto3
import os
import urllib3
import ssl
import socket
from datetime import datetime

# Try to import ldap3 for AD operations
try:
    from ldap3 import Server, Connection, ALL, NTLM, Tls
    LDAP_AVAILABLE = True
except ImportError:
    LDAP_AVAILABLE = False
    print("⚠️ ldap3 library not found. AD User creation will be skipped.")

# Initialize AWS clients
iam = boto3.client('iam')
ec2 = boto3.client('ec2')
secretsmanager = boto3.client('secretsmanager')
ssm = boto3.client('ssm')
dynamodb = boto3.resource('dynamodb')
http = urllib3.PoolManager()

# Configuration
SLACK_WEBHOOK = os.environ.get('SLACK_WEBHOOK_URL')
WORKSTATIONS_TABLE = os.environ.get('WORKSTATIONS_TABLE')
WORKSTATION_AMI = os.environ.get('WORKSTATION_AMI')
WORKSTATION_INSTANCE_TYPE = os.environ.get('WORKSTATION_INSTANCE_TYPE', 't3.medium')
WORKSTATION_SUBNET_ID = os.environ.get('WORKSTATION_SUBNET_ID')
WORKSTATION_SG_ID = os.environ.get('WORKSTATION_SG_ID')
WORKSTATION_PROFILE_NAME = os.environ.get('WORKSTATION_PROFILE_NAME')

# AD Configuration
DIRECTORY_ID = os.environ.get('DIRECTORY_ID')
DIRECTORY_NAME = os.environ.get('DIRECTORY_NAME', 'innovatech.local')
AD_SECRET_ARN = os.environ.get('AD_SECRET_ARN')
DOMAIN_JOIN_DOC = os.environ.get('DOMAIN_JOIN_DOC')

workstations_table = dynamodb.Table(WORKSTATIONS_TABLE)

def handler(event, context):
    print(f"Received event: {json.dumps(event)}")
    for record in event['Records']:
        if record['eventName'] == 'INSERT':
            handle_onboarding(record)
        elif record['eventName'] == 'REMOVE':
            handle_offboarding(record)
    return {'statusCode': 200, 'body': json.dumps('Processed')}

def handle_onboarding(record):
    new_image = record['dynamodb']['NewImage']
    emp_name = new_image['name']['S']
    emp_email = new_image['email']['S']
    emp_id = new_image['employee_id']['S']
    dept = new_image['department']['S']
    
    print(f"🆕 Onboarding: {emp_name} ({emp_email})")
    
    try:
        # 1. Create AD User
        ad_username = emp_email.split('@')[0]
        ad_password = None
        
        if LDAP_AVAILABLE and AD_SECRET_ARN:
            print("🩺 Running connectivity diagnostics...")
            diagnose_connectivity(DIRECTORY_NAME)
            
            print(f"🔌 Connecting to Active Directory: {DIRECTORY_NAME}...")
            ad_password = create_ad_user(
                emp_name, 
                ad_username, 
                emp_email, 
                dept, 
                DIRECTORY_NAME, 
                AD_SECRET_ARN
            )
        else:
            print("⚠️ Skipping AD creation (Missing Layer or Secret)")

        # 2. Create IAM User (Backup/Console Access)
        iam_username = emp_email.replace('@', '-').replace('.', '-')
        create_iam_user_safe(iam_username, emp_id, dept)

        # 3. Launch Workstation
        instance_id, private_ip = launch_workstation(emp_name, emp_id, dept)
        
        # 4. Join Domain (SSM)
        if instance_id and DIRECTORY_ID:
            print(f"🔗 Joining {instance_id} to {DIRECTORY_NAME}...")
            try:
                # Use the correct AWS document for domain join
                ssm.create_association(
                    Name='AWS-JoinDirectoryServiceDomain',  # ← Correct document name
                    Targets=[{'Key': 'InstanceIds', 'Values': [instance_id]}],
                    Parameters={
                        'directoryId': [DIRECTORY_ID],
                        'directoryName': [DIRECTORY_NAME]
                    }
                )
                print("✅ Domain Join Association created")
            except Exception as e:
                print(f"❌ Domain Join failed: {e}")

        # 5. Save State
        workstations_table.put_item(Item={
            'employee_id': emp_id,
            'instance_id': instance_id,
            'iam_username': iam_username,
            'ad_username': f"{DIRECTORY_NAME}\\{ad_username}",
            'status': 'provisioning',
            'created_at': datetime.utcnow().isoformat()
        })

        # 6. Slack Notification
        if SLACK_WEBHOOK:
            msg = f"*Name:* {emp_name}\n*AD User:* `{ad_username}`\n*Workstation:* `{instance_id}`"
            if ad_password:
                msg += f"\n*Initial Password:* ||{ad_password}||"
            send_slack("🎉 Enterprise Onboarding Complete", msg)

    except Exception as e:
        print(f"❌ Error: {str(e)}")
        raise e

def handle_offboarding(record):
    old_image = record['dynamodb']['OldImage']
    emp_id = old_image['employee_id']['S']
    emp_name = old_image['name']['S']
    
    print(f"🗑️ Offboarding: {emp_name}")
    
    try:
        # Terminate EC2
        resp = workstations_table.get_item(Key={'employee_id': emp_id})
        if 'Item' in resp:
            instance_id = resp['Item'].get('instance_id')
            if instance_id:
                ec2.terminate_instances(InstanceIds=[instance_id])
            workstations_table.delete_item(Key={'employee_id': emp_id})
            
        if SLACK_WEBHOOK:
            send_slack("👋 Employee Offboarded", f"Resources for {emp_name} have been cleaned up.")
            
    except Exception as e:
        print(f"❌ Error offboarding: {e}")

# --- Active Directory Helpers ---

def create_ad_user(name, username, email, dept, directory_name, secret_arn):
    """
    Creates a user in AWS Managed AD.
    Uses port 389 for user creation, port 636 for password setting.
    """
    
    # 1. Retrieve Credentials
    secret_val = secretsmanager.get_secret_value(SecretId=secret_arn)['SecretString']
    secret = json.loads(secret_val)
    admin_user = secret['username']
    admin_pass = secret['password']
    
    print(f"🔌 Connecting to Active Directory: {directory_name}...")
    
    # 2. Configure TLS with more permissive settings
    tls_config = Tls(
        validate=ssl.CERT_NONE,
        version=ssl.PROTOCOL_TLS  # Auto-negotiate TLS version
    )
    
    # 3. First, create user on port 389 (unencrypted - but doesn't set password)
    try:
        print(f"🛡️ Connecting to {directory_name}:389 for user creation...")
        server_389 = Server(
            directory_name,
            port=389,
            use_ssl=False,
            get_info=ALL,
            connect_timeout=10
        )
        
        conn_389 = Connection(
            server_389,
            user=f"{admin_user}@{directory_name}",
            password=admin_pass,
            auto_bind=True,
            receive_timeout=10
        )
        
        print(f"✅ Connected on port 389")
        
        # Create the user (without password)
        user_dn = _create_ad_user_object(conn_389, username, name, email, dept, directory_name)
        conn_389.unbind()
        
    except Exception as e:
        print(f"❌ Failed to create user object: {e}")
        raise e
    
    # 4. Now set password using LDAPS on port 636
    temp_password = f"Welcome{datetime.now().year}!"
    
    # Try to use domain name with LDAPS, fallback to IP if needed
    ldaps_attempts = [
        {'host': directory_name, 'desc': 'domain name'},
    ]
    
    # Also try direct IPs
    try:
        ip_list = socket.gethostbyname_ex(directory_name)[2]
        for ip in ip_list:
            ldaps_attempts.append({'host': ip, 'desc': f'IP {ip}'})
    except:
        pass
    
    password_set = False
    for attempt in ldaps_attempts:
        try:
            print(f"🔐 Attempting password set via LDAPS using {attempt['desc']}...")
            
            server_636 = Server(
                attempt['host'],
                port=636,
                use_ssl=True,
                tls=tls_config,
                get_info=ALL,
                connect_timeout=10
            )
            
            conn_636 = Connection(
                server_636,
                user=f"{admin_user}@{directory_name}",
                password=admin_pass,
                auto_bind=True,
                receive_timeout=10
            )
            
            print(f"✅ Connected via LDAPS using {attempt['desc']}")
            
            # Set password
            pwd_value = f'"{temp_password}"'.encode('utf-16-le')
            conn_636.modify(user_dn, {'unicodePwd': [(2, [pwd_value])]})
            
            if conn_636.result['result'] == 0:
                print(f"✅ Password set successfully via {attempt['desc']}")
                password_set = True
            else:
                print(f"⚠️ Password set failed via {attempt['desc']}: {conn_636.result['description']}")
            
            # Enable account
            conn_636.modify(user_dn, {'userAccountControl': [(2, [512])]})
            print(f"✅ Account enabled")
            
            conn_636.unbind()
            
            if password_set:
                break
                
        except Exception as e:
            print(f"❌ LDAPS failed using {attempt['desc']}: {e}")
            continue
    
    if not password_set:
        print(f"⚠️ WARNING: User created but password could not be set via LDAPS. Manual password reset required.")
    
    return temp_password

def _create_ad_user_object(conn, username, name, email, dept, directory_name):
    """Creates the AD user object (without password)"""
    
    dc_parts = directory_name.split('.')
    netbios_name = dc_parts[0].upper()
    
    # AWS Managed AD: Use the delegated OU
    dn = f"CN={username},OU={netbios_name},DC={dc_parts[0]},DC={dc_parts[1]}"
    
    print(f"🔧 Creating AD Object: {dn}")
    
    # Split name properly
    name_parts = name.strip().split()
    first_name = name_parts[0] if name_parts else username
    last_name = name_parts[-1] if len(name_parts) > 1 else username
    
    # Create User Object (without password - userAccountControl 544 means disabled)
    conn.add(dn, attributes={
        'objectClass': ['top', 'person', 'organizationalPerson', 'user'],
        'cn': username,
        'sAMAccountName': username,
        'userPrincipalName': email,
        'givenName': first_name,
        'sn': last_name,
        'displayName': name,
        'department': dept,
        'userAccountControl': 544  # Disabled until password is set
    })
    
    if conn.result['result'] == 0:
        print(f"✅ User object created")
    elif conn.result['result'] == 68:
        print(f"⚠️ User {username} already exists")
    else:
        raise Exception(f"User creation failed: {conn.result['description']}")
    
    return dn
def _perform_ad_operations(conn, username, name, email, dept, directory_name):
    """Internal helper to actually create the user once connected"""
    
    # Determine correct OU
    dc_parts = directory_name.split('.')
    netbios_name = dc_parts[0].upper()
    
    # Standard Users container (change if you have custom OUs)
    dn = f"CN={username},OU={netbios_name},DC={dc_parts[0]},DC={dc_parts[1]}"
    
    temp_password = f"Welcome{datetime.now().year}!"
    print(f"🔧 Creating AD Object: {dn}")
    
    # Split name properly
    name_parts = name.strip().split()
    first_name = name_parts[0] if name_parts else username
    last_name = name_parts[-1] if len(name_parts) > 1 else username
    
    # Create User Object
    try:
        conn.add(dn, attributes={
            'objectClass': ['top', 'person', 'organizationalPerson', 'user'],
            'cn': username,
            'sAMAccountName': username,
            'userPrincipalName': email,
            'givenName': first_name,
            'sn': last_name,
            'displayName': name,
            'department': dept,
            'userAccountControl': 544  # Normal account + password not required (temporarily)
        })
        
        if conn.result['result'] == 0:
            print(f"✅ User object created")
        elif conn.result['result'] == 68:
            print(f"⚠️ User {username} already exists. Updating password only.")
        else:
            raise Exception(f"User creation failed: {conn.result['description']}")
    except Exception as e:
        print(f"❌ User creation error: {e}")
        raise e
    
    # Set Password - Correct format for unicodePwd
    try:
        # Password must be enclosed in quotes and UTF-16-LE encoded
        pwd_value = f'"{temp_password}"'.encode('utf-16-le')
        
        conn.modify(dn, {
            'unicodePwd': [(2, [pwd_value])]  # MODIFY_REPLACE = 2
        })
        
        if conn.result['result'] == 0:
            print(f"✅ Password set successfully")
        else:
            print(f"⚠️ Password set result: {conn.result['description']}")
    except Exception as e:
        print(f"❌ Failed to set password: {e}")
        # Don't raise - user is created, can reset password manually
    
    # Enable Account (512 = normal enabled account)
    try:
        conn.modify(dn, {
            'userAccountControl': [(2, [512])]
        })
        print(f"✅ Account enabled")
    except Exception as e:
        print(f"⚠️ Failed to enable account: {e}")
    
    conn.unbind()
    return temp_password
# --- Infrastructure Helpers ---

def launch_workstation(name, emp_id, dept):
    user_data = f"""<powershell>
    Rename-Computer -NewName "WS-{emp_id[:8]}" -Force
    </powershell>
    """
    try:
        run_instances = ec2.run_instances(
            ImageId=WORKSTATION_AMI,
            InstanceType=WORKSTATION_INSTANCE_TYPE,
            MinCount=1, MaxCount=1,
            SubnetId=WORKSTATION_SUBNET_ID,
            SecurityGroupIds=[WORKSTATION_SG_ID],
            IamInstanceProfile={'Name': WORKSTATION_PROFILE_NAME},
            UserData=user_data,
            TagSpecifications=[{
                'ResourceType': 'instance',
                'Tags': [
                    {'Key': 'Name', 'Value': f"{name}-Workstation"},
                    {'Key': 'EmployeeId', 'Value': emp_id},
                    {'Key': 'Domain', 'Value': DIRECTORY_NAME}
                ]
            }]
        )
        inst = run_instances['Instances'][0]
        return inst['InstanceId'], inst.get('PrivateIpAddress')
    except Exception as e:
        print(f"❌ Failed to launch EC2: {e}")
        return None, None

def get_directory_ips():
    dirs = boto3.client('ds').describe_directories(DirectoryIds=[DIRECTORY_ID])
    return dirs['DirectoryDescriptions'][0]['DnsIpAddrs']

def create_iam_user_safe(username, emp_id, dept):
    try:
        iam.create_user(UserName=username, Tags=[{'Key': 'EmployeeId', 'Value': emp_id}])
    except iam.exceptions.EntityAlreadyExistsException:
        pass

def diagnose_connectivity(directory_name, port=636):
    print(f"🔍 Diagnosing connection to {directory_name}:{port}...")
    try:
        resolved_ips = socket.gethostbyname_ex(directory_name)
        print(f"✅ DNS Resolution OK: {resolved_ips[2]}")
        ips = resolved_ips[2]
    except socket.gaierror as e:
        print(f"❌ DNS Resolution FAILED: {e}")
        return False
    
    for ip in ips:
        try:
            sock = socket.create_connection((ip, port), timeout=3)
            sock.close()
            print(f"✅ TCP Reachable: {ip}:{port}")
        except Exception as e:
            print(f"❌ TCP Unreachable {ip}:{port} - {e}")
    return True

def send_slack(title, text):
    payload = {"text": title, "blocks": [{"type": "section", "text": {"type": "mrkdwn", "text": text}}]}
    try:
        http.request('POST', SLACK_WEBHOOK, body=json.dumps(payload).encode('utf-8'), headers={'Content-Type': 'application/json'})
    except: pass